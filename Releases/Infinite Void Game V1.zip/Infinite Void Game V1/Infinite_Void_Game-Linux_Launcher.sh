java -jar 'Infinite Void Game.jar'
